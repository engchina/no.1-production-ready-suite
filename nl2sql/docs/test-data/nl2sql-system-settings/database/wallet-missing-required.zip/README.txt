This ZIP intentionally misses tnsnames.ora and cwallet.sso for negative tests.
